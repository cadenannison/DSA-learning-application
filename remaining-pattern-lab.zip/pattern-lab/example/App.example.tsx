/**
 * Minimal usage example — not part of the package, just a reference for
 * wiring PatternLab into a page/route.
 */
import { PatternLab, PATTERNS, SOON_PATTERNS } from '../src';

export default function StudyPlanPatternLabPage() {
  return (
    <PatternLab
      patterns={PATTERNS}
      soonPatterns={SOON_PATTERNS}
      initialPatternId="dp"
    />
  );
}

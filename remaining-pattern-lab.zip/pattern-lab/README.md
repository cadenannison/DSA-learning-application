# Pattern Lab

A self-serve, interactive DSA lesson component. All **14** patterns in the
study plan are fully content-authored and wired live: Dynamic Programming,
Graphs, Backtracking, BFS/DFS, Binary Search, Greedy, Heaps, Intervals,
Linked List, Sliding Window, Stacks/Queues, Trees, Tries, and Two Pointers.
`SOON_PATTERNS` is now empty — there are no disabled tabs left.

Prototyped as a standalone HTML artifact, then ported to this React/TS
component set — the instrumented trace logic is unchanged, just typed and
split into modules (one trace-builder file and one content file per
pattern, under `src/traceBuilders/` and `src/content/`).

Trees, Tries, Linked List, and parts of BFS/DFS and Heaps (Merge K Sorted
Lists) render as an actual **positioned tree/graph with drawn edges** —
nodes placed at explicit x/y coordinates with SVG lines between them —
rather than the flat chip grid used for DAG/Union-Find style graphs in the
Graphs pattern. See "Node positioning" below.

## What it does

Each pattern has a mini menu with three sections, plus a shared **Simple →
Hard depth stepper** that applies across all of them:

- **Learn** — a "Concept" page whose reading gets more advanced as you move
  up the depth ladder (Simple: "here's what this is", ... Hard: the genuinely
  hard parts), and a flat "Syntax Reference" page of idiom cards.
- **Recognize It** — cue chips and annotated real-problem-statement snippets
  that get subtler at each depth level, teaching what to scan for in a new
  problem.
- **Practice** — a step-through visualizer over **real, instrumented code**
  (not hand-scripted animations — the trace functions actually run the
  algorithm and record what happened at each step). One problem per depth
  tier; ties within a tier (e.g. two Hard problems) get a small sub-picker.

## Integration

```tsx
import { PatternLab, PATTERNS, SOON_PATTERNS } from './pattern-lab/src';

<PatternLab patterns={PATTERNS} soonPatterns={SOON_PATTERNS} initialPatternId="dp" />
```

Requirements:
- React 18+ (uses `useState`/`useMemo`/`useEffect` only — no router, no global store).
- `color-mix()` CSS support (all evergreen browsers; this is how per-pattern
  accent tints and dark mode are derived without hand-authoring a second
  color for every token).
- Fonts: the design uses **Sora** (headings/UI), **IBM Plex Sans** (body),
  and **JetBrains Mono** (code). Add to your app's `<head>`:
  ```html
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700;800&family=IBM+Plex+Sans:wght@400;500;600&family=JetBrains+Mono:wght@400;500;600&display=swap">
  ```
  If you'd rather use the app's existing type system, it degrades fine —
  `PatternLab.css` falls back to `system-ui` / `ui-monospace`.
- `PatternLab.css` is scoped entirely under `.pattern-lab` (no bare `body`,
  `h1..h3`, or `*` selectors), so it's safe to import globally without
  leaking into the rest of the app.
- Dark mode: follows `prefers-color-scheme` by default; an ancestor can force
  a theme by setting `data-theme="light"` or `data-theme="dark"` on any
  element above `.pattern-lab` (or on it directly).

## File map

```
src/
  types.ts                — the content schema (Pattern, PatternLevel, Variant, Trace, ...)
  traceBuilders/
    dp.ts, graphs.ts, backtracking.ts, bfsDfs.ts, binarySearch.ts,
    greedy.ts, heaps.ts, intervals.ts, linkedList.ts, slidingWindow.ts,
    stacksQueues.ts, trees.ts, tries.ts, twoPointers.ts
                            — one file per pattern, instrumented trace-builder
                              functions (one per Practice problem)
    index.ts                — re-exports all of the above
  content/
    dp.ts, graphs.ts, backtracking.ts, ... (same 14, mirrored)
                            — one finished Pattern object per file
    index.ts                — PATTERNS[] registry (all 14) + SOON_PATTERNS[] (now empty)
  visualizers/
    CodePanel.tsx            — highlights the active line
    ArrayViz.tsx              — 1D array/table; also renders an optional shaded
                                 [left, right] window and optional side `panels`
                                 (a stack/deque/heap's live contents as chips)
    MatrixViz.tsx              — 2D table (LCS, Edit Distance, Kth Smallest in Matrix)
    GridViz.tsx                 — grid the algorithm walks (flood-fill, N-Queens, Word Search)
    NodeViz.tsx                  — two modes: (a) flat chip grid + panels, for
                                    graphs better described than drawn (topological
                                    sort, Dijkstra, Union-Find, Word Ladder); (b) a
                                    POSITIONED tree/graph with drawn SVG edges, used
                                    when every node in a step carries x/y — this is
                                    what Trees, Tries, Linked List, and a few
                                    BFS/DFS + Heaps variants use (see below)
  components/
    PatternStrip.tsx          — top pattern tabs (no "soon" placeholders left — all 14 are live)
    MiniMenu.tsx                — Learn / Recognize It / Practice
    LevelStepper.tsx             — the shared Simple→Hard depth stepper
    LearnSection.tsx               — Concept + Syntax Reference pages
    RecognizeSection.tsx            — cues + annotated example snippets
    PracticeSection.tsx              — owns step/playing/speed state, renders the workbench
  PatternLab.tsx           — top-level component, owns pattern/section/level state
  PatternLab.css           — all styles, scoped under .pattern-lab
  index.ts                 — public exports
example/
  App.example.tsx           — minimal usage reference (not part of the package)
```

## Node positioning — drawing an actual tree/graph

`NodeItem` supports optional `x`/`y` (0–100, a shared viewBox), and `NodeStep`
supports optional `edges: NodeEdge[]` (`{ from, to, label?, state?, directed? }`).
When every node in a step has `x`/`y` **and** the step has `edges`, `NodeViz`
draws a real positioned diagram — circles at their coordinates, SVG lines
(with optional arrowheads and edge labels) between them — instead of the flat
wrap-and-chip grid. Trees lay out top-down (root at the top, children spread
beneath); Tries put the traversed character on the edge `label` since a
trie's information lives on its edges; Linked List draws a left-to-right
chain with `directed: true` "next" edges, recomputed every step so the
picture always matches the real, currently-rewired pointer state — never a
canned animation. Leave `edges`/`x`/`y` off (as Graphs' course-schedule,
network-delay, and redundant-connection do) for graphs that read better as
a flat set of chips + side panels than as a literal drawing.

## Authoring another pattern, or revising one of the 14

Each pattern is one `Pattern` object (see `src/types.ts` for the full,
commented schema). Copy `src/content/graphs.ts` (flat node style) or
`src/content/trees.ts` (positioned node style) as a starting template.
Checklist:

1. **Pick 5 variants spanning Simple → Hard.** One per tier is required;
   Hard commonly gets two (harder patterns tend to fork into two distinct
   hard techniques — e.g. Graphs hard-forks into Dijkstra vs. Union-Find).
   Assign each a `difficulty` of `'simple' | 'easy' | 'medium' | 'hard'`.

2. **Write a trace builder per variant**, in its own file under
   `src/traceBuilders/`, following the existing ones as templates. The
   non-negotiable rule: **run the real algorithm and record steps as it
   executes** — never hand-write a fake step sequence. Pick the matching
   `VizType`:
   - `array` — a 1D table, a window, or a stack/deque/heap-as-array (use
     `left`/`right` for a window range, `panels` for stack/deque/heap contents)
   - `matrix` — a 2D table (DP over two sequences/indices, a sorted matrix)
   - `grid` — a 2D grid the algorithm walks (flood-fill, multi-source BFS, backtracking over a board)
   - `nodes` — either a flat chip grid + panels (topological sort, Dijkstra,
     Union-Find, word-graph BFS), or, with `x`/`y` on every node and `edges`
     set, a real positioned tree/graph drawing (see above) — prefer the
     positioned mode whenever the structure genuinely is a tree/graph shape
     (trees, tries, linked lists, small non-DAG graphs)
   Each `TraceStep` needs a `line` key that matches one of your `lines[].k`
   values — that's what drives the active-line highlight. Re-export the new
   file from `src/traceBuilders/index.ts`.

3. **Write the 4 `levels` entries** (`tier` must be exactly `'simple'`,
   `'easy'`, `'medium'`, `'hard'`, in that order). For each: a short
   `learnHeading` + `learnBody` (the reading gets deeper each level — Simple
   should assume zero vocabulary, Hard should name the actually-hard
   sub-techniques), 2–3 `learnFocus` bullets, 1–2 `cues`, and 1–2 `examples`
   (realistic quoted problem-statement phrasing + what it signals). Put a
   `confuse` callout on whichever level is where people most often confuse
   this pattern with a neighboring one (e.g. DP vs. Greedy sits at Medium;
   Two Pointers vs. Sliding Window sits at Medium in those patterns).

4. **Write `syntax`**: 4–6 short idiom cards — the syntax someone would want
   memorized, not prose explanation. Keep each `code` snippet under ~8 lines.

5. Add the pattern to `PATTERNS` and its file to the imports in
   `src/content/index.ts`, and remove its label from `SOON_PATTERNS` if it
   was still listed there.

6. Sanity-check a new trace builder before shipping it: call it directly and
   print the last step's `note` — it should match the known correct answer
   for that classic problem. (This is how every trace in all 14 patterns was
   verified — run against a plain-JS reference or the textbook answer before
   the content was finalized. `npx tsx` can run a `.ts` file directly for
   this kind of one-off check.)

## Design notes for whoever picks this up

- State lives entirely in `PatternLab.tsx` (pattern/section/level) and
  `PracticeSection.tsx` (step/playing/speed, reset on variant change) — no
  external state management needed.
- Traces are memoized per `variant.id` inside `PracticeSection` via a
  `useRef` cache, so switching tabs and coming back doesn't re-run the
  algorithm.
- `dangerouslySetInnerHTML` is used in a few places (`statement`, `learnBody`,
  `confuse`, example `snippet`/`tell`, and the graph `adjHtml`) because
  content authors use `<b>` for emphasis. This content is **author-controlled
  only** — never pass user input through these fields.
- The per-pattern accent color is threaded as CSS custom properties
  (`--pl-accent-light` / `--pl-accent-dark`) set inline on the root
  `.pattern-lab` element from `pattern.accent` / `pattern.accentDark`, and
  again per-tab in `PatternStrip.tsx` so inactive tabs keep their own hint
  color. Everything else reads the resolved `--pl-accent` token, and the
  "soft" tint is derived with `color-mix()` rather than a second authored
  color per pattern.
